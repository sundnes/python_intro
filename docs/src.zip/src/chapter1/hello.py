#The simplest possible python program:
print('Hello, World!')
