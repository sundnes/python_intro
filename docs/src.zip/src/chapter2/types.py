primary = 100.0
r = 2.5
n = 4
hello = "Hello, World!"

#check the types of the variables:
print(type(hello))
print(type(r))
print(type(primary))
print(type(n))
